# np_selltonpc
 A script to sell drugs to NPC, optimised client side.
